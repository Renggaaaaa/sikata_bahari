-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 15, 2022 at 12:47 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_kas`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `nama` varchar(40) NOT NULL,
  `email` varchar(40) NOT NULL,
  `pass` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `nama`, `email`, `pass`) VALUES
(1, 'Admin1', 'admin1@mail.com', 'admin123'),
(2, 'Admin2', 'admin2@mail.com', 'tes123'),
(6, 'lia', 'lia@mail.com', '12345');

-- --------------------------------------------------------

--
-- Table structure for table `catatan`
--

CREATE TABLE `catatan` (
  `id_catatan` int(11) NOT NULL,
  `catatan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `catatan`
--

INSERT INTO `catatan` (`id_catatan`, `catatan`) VALUES
(1, 'Tetap Mengontrol Pemasukan dan Pengeluaran'),
(2, 'Tingkatkan lagi pendapatan, dan minimalkan pengeluaran');

-- --------------------------------------------------------

--
-- Table structure for table `karyawan`
--

CREATE TABLE `karyawan` (
  `id_karyawan` int(11) NOT NULL,
  `nama` varchar(40) NOT NULL,
  `posisi` varchar(40) NOT NULL,
  `alamat` varchar(40) NOT NULL,
  `umur` int(11) NOT NULL,
  `kontak` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `karyawan`
--

INSERT INTO `karyawan` (`id_karyawan`, `nama`, `posisi`, `alamat`, `umur`, `kontak`) VALUES
(1, 'saiful', 'ketua', 'mns.aron', 19, '0888888'),
(6, 'Riza', 'Bendahara', 'Aceh', 19, '08333333333');

-- --------------------------------------------------------

--
-- Table structure for table `kaskeluarperbulan`
--

CREATE TABLE `kaskeluarperbulan` (
  `id_kaskeluar_perbulan` int(11) NOT NULL,
  `bulan_keluar` varchar(255) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `id_sumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kaskeluarperbulan`
--

INSERT INTO `kaskeluarperbulan` (`id_kaskeluar_perbulan`, `bulan_keluar`, `jumlah`, `id_sumber`) VALUES
(1, 'Maret', 1100000, 10),
(3, 'Februari', 200000, 7),
(4, 'Januari', 3000000, 6),
(20, 'Januari', 700000, 8),
(21, 'April', 90000, 9);

-- --------------------------------------------------------

--
-- Table structure for table `kaskeluarperhari`
--

CREATE TABLE `kaskeluarperhari` (
  `id_kaskeluar_perhari` int(11) NOT NULL,
  `tgl_pengeluaran` date NOT NULL,
  `jumlah` int(11) NOT NULL,
  `id_sumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kaskeluarperhari`
--

INSERT INTO `kaskeluarperhari` (`id_kaskeluar_perhari`, `tgl_pengeluaran`, `jumlah`, `id_sumber`) VALUES
(1, '2019-10-22', 1100000, 10),
(3, '2019-10-16', 200000, 7),
(4, '2019-10-17', 3000000, 6),
(5, '2019-10-18', 100000, 7),
(6, '2019-10-19', 150000, 6),
(7, '2019-10-20', 100000, 7),
(8, '2019-10-21', 150000, 6),
(9, '2019-10-23', 123000, 9),
(10, '2019-10-15', 600000, 6),
(11, '2019-10-13', 20000, 7),
(12, '2019-10-12', 300000, 9),
(13, '2019-10-24', 500000, 8),
(14, '2019-10-30', 121212, 6),
(15, '2019-10-25', 60000, 6),
(16, '2019-10-26', 70000, 7),
(17, '2019-10-27', 60000, 8),
(18, '2019-10-28', 78000, 9),
(19, '2019-10-29', 79000, 10);

-- --------------------------------------------------------

--
-- Table structure for table `kasmasukperbulan`
--

CREATE TABLE `kasmasukperbulan` (
  `id_kasmasuk_perbulan` int(11) NOT NULL,
  `bulan_masuk` varchar(255) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `id_sumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kasmasukperbulan`
--

INSERT INTO `kasmasukperbulan` (`id_kasmasuk_perbulan`, `bulan_masuk`, `jumlah`, `id_sumber`) VALUES
(1, 'Januari', 700000, 1),
(2, 'Februari', 90000, 2),
(3, 'Maret', 800000, 3),
(4, 'April', 100000, 4),
(5, 'Mei', 500000, 5);

-- --------------------------------------------------------

--
-- Table structure for table `kasmasukperhari`
--

CREATE TABLE `kasmasukperhari` (
  `id_kasmasuk_perhari` int(11) NOT NULL,
  `tgl_pemasukan` date NOT NULL,
  `jumlah` int(11) NOT NULL,
  `id_sumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kasmasukperhari`
--

INSERT INTO `kasmasukperhari` (`id_kasmasuk_perhari`, `tgl_pemasukan`, `jumlah`, `id_sumber`) VALUES
(1, '2019-10-16', 100000, 1),
(4, '2019-10-18', 400000, 3),
(39, '2022-06-09', 90000, 2),
(41, '2022-06-04', 300000, 5),
(42, '2022-06-04', 200000, 4),
(43, '2019-06-07', 100000, 3);

-- --------------------------------------------------------

--
-- Table structure for table `sumber`
--

CREATE TABLE `sumber` (
  `id_sumber` int(11) NOT NULL,
  `nama` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sumber`
--

INSERT INTO `sumber` (`id_sumber`, `nama`) VALUES
(1, 'Tiket'),
(2, 'Wahana'),
(3, 'Toilet'),
(4, 'Parkir'),
(5, 'Sewa Tikar'),
(6, 'Gaji Karyawan'),
(7, 'Pemeliharaan Wahana'),
(8, 'Listrik'),
(9, 'Air'),
(10, 'Wifi');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `catatan`
--
ALTER TABLE `catatan`
  ADD PRIMARY KEY (`id_catatan`);

--
-- Indexes for table `karyawan`
--
ALTER TABLE `karyawan`
  ADD PRIMARY KEY (`id_karyawan`);

--
-- Indexes for table `kaskeluarperbulan`
--
ALTER TABLE `kaskeluarperbulan`
  ADD PRIMARY KEY (`id_kaskeluar_perbulan`),
  ADD KEY `id_sumber` (`id_sumber`);

--
-- Indexes for table `kaskeluarperhari`
--
ALTER TABLE `kaskeluarperhari`
  ADD PRIMARY KEY (`id_kaskeluar_perhari`),
  ADD KEY `id_sumber` (`id_sumber`);

--
-- Indexes for table `kasmasukperbulan`
--
ALTER TABLE `kasmasukperbulan`
  ADD PRIMARY KEY (`id_kasmasuk_perbulan`),
  ADD KEY `id_sumber` (`id_sumber`);

--
-- Indexes for table `kasmasukperhari`
--
ALTER TABLE `kasmasukperhari`
  ADD PRIMARY KEY (`id_kasmasuk_perhari`),
  ADD KEY `id_sumber` (`id_sumber`);

--
-- Indexes for table `sumber`
--
ALTER TABLE `sumber`
  ADD PRIMARY KEY (`id_sumber`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `catatan`
--
ALTER TABLE `catatan`
  MODIFY `id_catatan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `karyawan`
--
ALTER TABLE `karyawan`
  MODIFY `id_karyawan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `kaskeluarperbulan`
--
ALTER TABLE `kaskeluarperbulan`
  MODIFY `id_kaskeluar_perbulan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `kaskeluarperhari`
--
ALTER TABLE `kaskeluarperhari`
  MODIFY `id_kaskeluar_perhari` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `kasmasukperbulan`
--
ALTER TABLE `kasmasukperbulan`
  MODIFY `id_kasmasuk_perbulan` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `kasmasukperhari`
--
ALTER TABLE `kasmasukperhari`
  MODIFY `id_kasmasuk_perhari` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `sumber`
--
ALTER TABLE `sumber`
  MODIFY `id_sumber` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
