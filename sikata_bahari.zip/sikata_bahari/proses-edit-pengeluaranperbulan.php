<?php
//include('dbconnected.php');
include('koneksi.php');

$id = $_GET['id_kaskeluar_perbulan'];
$bln = $_GET['bulan_keluar'];
$jumlah = $_GET['jumlah'];
$sumber = $_GET['id_sumber'];

//query update
$query = mysqli_query($koneksi,"UPDATE kaskeluarperbulan SET bulan_keluar='$bln' , jumlah='$jumlah', id_sumber='$sumber' WHERE id_kaskeluar_perbulan='$id' ");

if ($query) {
 # credirect ke page index
 header("location:kaskeluarperbulan.php"); 
}
else{
 echo "ERROR, data gagal diupdate". mysqli_error($koneksi);
}

//mysql_close($host);
?>