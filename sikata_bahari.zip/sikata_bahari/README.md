# Sistem-informasi-keuangan

## Demo Beranda :

![demo](https://user-images.githubusercontent.com/45083824/69827196-e52b8000-1248-11ea-978d-7cd8b2b4a72a.png)

## Demo Pengeluaran :

![pengeluaran](https://user-images.githubusercontent.com/45083824/69827194-e52b8000-1248-11ea-94d6-a5a1408229e8.png)

## Export excel :

![export](https://user-images.githubusercontent.com/45083824/69827193-e492e980-1248-11ea-9f44-9d561db4bb60.png)

Sistem informasi keuangan
SIMKEU


