<?php
//include('dbconnected.php');
include('koneksi.php');

$bulan_masuk = $_GET['bulan_masuk'];
$jumlah = $_GET['jumlah'];
$sumber = $_GET['sumber'];

//query update
$query = mysqli_query($koneksi,"INSERT INTO `kasmasukperbulan` (`bulan_masuk`, `jumlah`, `id_sumber`) VALUES ('$bulan_masuk', '$jumlah', '$sumber')");

if ($query) {
 # credirect ke page index
 header("location:kasmasukperbulan.php"); 
}
else{
 echo "ERROR, data gagal diupdate". mysqli_error($koneksi);
}

//mysql_close($host);
?>