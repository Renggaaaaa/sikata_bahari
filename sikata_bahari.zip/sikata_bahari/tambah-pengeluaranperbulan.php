<?php
//include('dbconnected.php');
include('koneksi.php');

$bulan_keluar = $_GET['bulan_keluar'];
$jumlah = $_GET['jumlah'];
$sumber = $_GET['sumber'];

//query update
$query = mysqli_query($koneksi,"INSERT INTO `kaskeluarperbulan` (`bulan_keluar`, `jumlah`, `id_sumber`) VALUES ('$bulan_keluar', '$jumlah', '$sumber')");

if ($query) {
 # credirect ke page index
 header("location:kaskeluarperbulan.php"); 
}
else{
 echo "ERROR, data gagal diupdate". mysqli_error($koneksi);
}

//mysql_close($host);
?>