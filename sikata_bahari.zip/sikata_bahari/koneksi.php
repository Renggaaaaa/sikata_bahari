<?php

$host = 'localhost';
$nama = 'root';
$pass = '';
$db = 'db_kas';

$koneksi = mysqli_connect($host, $nama,$pass, $db);
?>