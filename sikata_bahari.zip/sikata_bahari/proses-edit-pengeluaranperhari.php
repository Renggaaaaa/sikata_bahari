<?php
//include('dbconnected.php');
include('koneksi.php');

$id = $_GET['id_kaskeluar_perhari'];
$tgl = $_GET['tgl_pengeluaran'];
$jumlah = $_GET['jumlah'];
$sumber = $_GET['id_sumber'];

//query update
$query = mysqli_query($koneksi,"UPDATE kaskeluarperhari SET tgl_pengeluaran='$tgl' , jumlah='$jumlah', id_sumber='$sumber' WHERE id_kaskeluar_perhari='$id' ");

if ($query) {
 # credirect ke page index
 header("location:kaskeluarperhari.php"); 
}
else{
 echo "ERROR, data gagal diupdate". mysqli_error($koneksi);
}

//mysql_close($host);
?>