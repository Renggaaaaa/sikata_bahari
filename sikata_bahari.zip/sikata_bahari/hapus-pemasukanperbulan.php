<?php
//include('dbconnected.php');
include('koneksi.php');

$id = $_GET['id_kasmasuk_perbulan'];

//query update
$query = mysqli_query($koneksi,"DELETE FROM `kasmasukperbulan` WHERE id_kasmasuk_perbulan = '$id'");

if ($query) {
 # credirect ke page index
 header("location:kasmasukperbulan.php"); 
}
else{
 echo "ERROR, data gagal diupdate". mysqli_error($koneksi);
}

//mysql_close($host);
?>