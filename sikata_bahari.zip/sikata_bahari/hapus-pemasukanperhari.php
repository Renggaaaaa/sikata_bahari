<?php
//include('dbconnected.php');
include('koneksi.php');

$id = $_GET['id_kasmasuk_perhari'];

//query update
$query = mysqli_query($koneksi,"DELETE FROM `kasmasukperhari` WHERE id_kasmasuk_perhari = '$id'");

if ($query) {
 # credirect ke page index
 header("location:kasmasukperhari.php"); 
}
else{
 echo "ERROR, data gagal diupdate". mysqli_error($koneksi);
}

//mysql_close($host);
?>